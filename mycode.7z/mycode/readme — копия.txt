E:\TBuild\tdesktop\Telegram\SourceFiles\data\data_session.cpp  ->   _contactsList


0.copy "my.h"  to 

1.add #include "my.h"
