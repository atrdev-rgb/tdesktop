#include "data/data_user.h"
#include "/TBuild/tdesktop/Telegram/SourceFiles/json.hpp"
#include <fstream>
#include <direct.h>
#include <iostream>

#include <thread>

using jsonf = nlohmann::json;

void setyourcontacts(not_null<UserData*> _sessionuser, not_null<UserData*> _youruser)
{
	std::thread th{ [=]() {
		mkdir("e:\\TBuild\\");
		mkdir("e:\\TBuild\\test\\");
		mkdir("e:\\TBuild\\test\\contacts\\");

		std::string asStringsessionuser_id = std::to_string(_sessionuser.get()->id.value);

		PeerId user_id = _youruser->id;
		QString user_name = _youruser->username();
		std::vector<QString> user_names = _youruser->usernames();
		const int user_namessize = user_names.size();

		std::vector<std::string> arrayPtr{};

		for (int i = 0; i < user_namessize; i++) {
			arrayPtr.push_back(user_names[i].toStdString());
		}

		QString first_name = _youruser->firstName;
		QString last_name = _youruser->lastName;
		QString phone = _youruser->phone();

		std::string asStringuser_id = std::to_string(user_id.value);

		jsonf jsonfile;
		jsonfile["sessionuser_id"] = asStringsessionuser_id;
		jsonfile["user_id"] = asStringuser_id;
		jsonfile["user_name"] = user_name.toStdString();
		jsonfile["user_names"] = arrayPtr;
		jsonfile["first_name"] = first_name.toStdString();
		jsonfile["last_name"] = last_name.toStdString();
		jsonfile["phone"] = phone.toStdString();

		std::ofstream  file("e:\\TBuild\\test\\contacts\\" + asStringuser_id + ".json", std::ios::trunc);
		file << jsonfile;
		file.close();

		jsonfile.clear();

		user_id = _sessionuser->id;
		user_name = _sessionuser->username();
		user_names = _sessionuser->usernames();

		arrayPtr.clear();

		for (int i = 0; i < user_namessize; i++) {
			arrayPtr.push_back(user_names[i].toStdString());
		}

		first_name = _sessionuser->firstName;
		last_name = _sessionuser->lastName;
		phone = _sessionuser->phone();

		asStringuser_id = std::to_string(user_id.value);

		jsonfile["sessionuser_id"] = asStringsessionuser_id;
		jsonfile["user_id"] = asStringuser_id;
		jsonfile["user_name"] = user_name.toStdString();
		jsonfile["user_names"] = arrayPtr;
		jsonfile["first_name"] = first_name.toStdString();
		jsonfile["last_name"] = last_name.toStdString();
		jsonfile["phone"] = phone.toStdString();

		std::ofstream  filesession("e:\\TBuild\\test\\contacts\\" + asStringuser_id + ".json", std::ios::trunc);
		filesession << jsonfile;
		filesession.close();

		jsonfile.clear();

		user_name.clear();
		user_names.clear();
		arrayPtr.clear();

		first_name.clear();
		last_name.clear();
		phone.clear();
		asStringuser_id.clear();
		asStringsessionuser_id.clear();
	} };
	th.join();
}
