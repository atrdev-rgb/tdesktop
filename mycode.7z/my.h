#include "data/data_session.h"
#include "data/data_user.h"
#include <mutex>          // std::mutex

std::mutex mtx;           // mutex for critical section
std::list<not_null<UserData*>> my_list;
bool isnew = false;

void setyourcontacts(not_null<UserData*> _youruser)
{
	mtx.lock();
	bool found = (std::find(my_list.begin(), my_list.end(), _youruser) != my_list.end());
	if (!found) {
		my_list.push_back(_youruser);
		isnew = true;
	}
	mtx.unlock();
}

void saveyourtofile()
{
	mtx.lock();

	std::list<not_null<UserData*>>::iterator it;
	for (it = my_list.begin(); it != my_list.end(); it++)
	{
		// Access the object through iterator
		//int id = it->id;
		//std::string name = it->name;

		//Print the contents
		//std::cout << id << " :: " << name << std::endl;
	}

	isnew = false;
	mtx.unlock();
}